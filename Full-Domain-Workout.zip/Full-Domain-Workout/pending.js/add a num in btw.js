//addd a number in between 2 and 3

arr = [1,2,4,5]

arr.splice(2,0,3)

console.log(arr);
