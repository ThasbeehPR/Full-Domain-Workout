process.on('message',(message)=>{
    console.log(`message from parent ${message}`);
})
process.on('child say hiii')