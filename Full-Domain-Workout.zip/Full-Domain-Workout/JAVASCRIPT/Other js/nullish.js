//nullish operator (??)

let foo = 'Hello';
let bar = null ?? foo ;
console.log(bar); // Output: 'Hello'
