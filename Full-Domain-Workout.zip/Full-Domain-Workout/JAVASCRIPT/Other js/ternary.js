//Ternary operation

// condition ? expressionIfTrue : expressionIfFalse;

num=5

const result =  num%2==0?'Even':'Odd'

console.log(result);

