//immediate execute

setImmediate(() => {
    console.log('Hii');
},4000);


