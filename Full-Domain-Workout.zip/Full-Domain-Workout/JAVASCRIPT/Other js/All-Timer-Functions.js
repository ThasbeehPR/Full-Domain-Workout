setTimeout(()=>{
    console.log('set TimeOut');
},1000)

let set=setInterval(()=>{
    console.log('set intervel');
},1000)

setTimeout(() => {
    clearInterval(set)
}, 4000);
setImmediate(()=>{
    console.log('set immediate');
})
process.nextTick(()=>{
    console.log('process nextTick');
})


let i=0;
let intervel=setInterval(()=>{
    console.log(i);
    i++
    if(i>10){
        clearInterval(intervel)
    }
},1000)