//Array   //need correct order(position)  name doesn't matter

const color=['Black','White','Green','Red']

const [one,two,three,four]=color
console.log(one);
console.log(two);
console.log(three);
console.log(four);


//object   //need correct key name order doesn't matter
person={
    name:'Thasbii',
    age:22,
    place:'Thrissur',
    job:'Full stack developer'
}


const {name,place,job,age}=person

console.log(name);
console.log(age);
console.log(place);
console.log(job);