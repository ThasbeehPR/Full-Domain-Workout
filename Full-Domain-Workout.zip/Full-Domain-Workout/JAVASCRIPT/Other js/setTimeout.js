setTimeout(()=>{
    console.log('Hii');
},2000)