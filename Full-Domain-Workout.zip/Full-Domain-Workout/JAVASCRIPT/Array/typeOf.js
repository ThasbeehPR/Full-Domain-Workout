//to check its dataType

let a="10"
let b = typeof(a)
console.log(b);

