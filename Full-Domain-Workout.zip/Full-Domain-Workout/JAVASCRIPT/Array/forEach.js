// Executes a provided function once for each array element.
let arr = [1, 2, 3];

arr.forEach((x)=>{{
    console.log(x);
}})
