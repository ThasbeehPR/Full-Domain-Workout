let arr = [1, 2, 3];

arr.push(4); // arr is now [1, 2, 3, 4]

arr.pop(); // returns 4, arr is now [1, 2, 3]

arr.shift(); // returns 1, arr is now [2, 3]

arr.unshift(1); // arr is now [1, 2, 3]

console.log(arr.includes(2)); 


