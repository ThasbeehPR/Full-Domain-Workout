
let arr = [6, 7, 8, 5, 2];
arr = arr.slice(2,-1); //+ve two 2 value remove first   //-ve last value remove
console.log(arr); //8,5


//to create a shallow copy of a portion of an array without modifying the original array.
//syntax-array.slice(start, end)
//+Ve value remove index value of staring elements
//-ve value remove other than 