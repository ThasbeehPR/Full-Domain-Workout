let arr = [1, 2, 3, 4];
arr.splice(1, 1,33);
console.log(arr);

//to add, remove, or replace elements in an array. This method modifies the original array.
//array.splice(start, deleteCount, item1, item2, ...);
