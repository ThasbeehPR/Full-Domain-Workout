//IIFE - it create a private scope

(function setT(){
    setTimeout(()=>{
        console.log('Hii');
    },3000)
})();