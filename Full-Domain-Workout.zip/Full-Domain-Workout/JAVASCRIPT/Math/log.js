// log(x): Returns the natural logarithm (base E) of x.
console.log(Math.log(1));
//0

//Math.log10(x): Returns the base-10 logarithm of x
console.log(Math.log10(100));
//100