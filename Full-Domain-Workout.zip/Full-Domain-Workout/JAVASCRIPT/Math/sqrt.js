//sqrt(x) - Returns the square root of x

x=16
console.log(Math.sqrt(x));