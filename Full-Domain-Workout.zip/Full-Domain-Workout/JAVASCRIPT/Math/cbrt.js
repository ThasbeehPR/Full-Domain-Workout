//cbrt(x): Returns the cube root of x.
let x=27;
console.log(Math.cbrt(x));
//3