// Represents Euler's number    constant value

console.log(Math.E);