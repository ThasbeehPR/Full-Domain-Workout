//Round - return the value of nearest integer


//EXAMPLE 1
let x= 3.3;
console.log(Math.round(x));

//EXAMPLE 2
let y= 3.7;
console.log(Math.round(y));


