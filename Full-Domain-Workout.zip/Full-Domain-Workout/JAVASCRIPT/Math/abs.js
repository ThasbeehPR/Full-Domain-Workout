//abs(x): Returns the absolute value of x

let x = -57;

console.log(Math.abs(x));