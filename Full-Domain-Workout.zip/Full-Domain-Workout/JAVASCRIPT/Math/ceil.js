//ceil - Returns the value of x rounded up to the next largest integer

let x=4.1;
console.log(Math.ceil(x));

