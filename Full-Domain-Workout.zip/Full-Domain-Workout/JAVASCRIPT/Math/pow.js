// pow(x, y): Returns the value of x 'raised to the power' of y (x^y)

let x=2
console.log(Math.pow(x,2));