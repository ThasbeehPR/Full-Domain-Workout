// floor - Returns the value of x rounded down to the next smallest integer.

let x=4.9

console.log(Math.floor(x));