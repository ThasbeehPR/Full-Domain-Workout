//give random values
// console.log(Math.random());


// const rand = Math.floor(Math.random())
// console.log(rand);


// function randomBtw1to100 (max){
//     return Math.floor(Math.random()*max+1)
// }
// console.log(randomBtw1to100(100));


// function randomBtw30to40 (min,max){
//     return Math.floor(Math.random()*(max-min+1)+min)
// }
// console.log(randomBtw30to40(30,40));

// let min = 20;
// let max = 30;
//syntax :-
//let randomInt = Math.floor(Math.random() * (max - min + 1)) + min;
//here last +min to not starrt with 0

console.log(Math.floor(Math.random()*(50-40))+40);
