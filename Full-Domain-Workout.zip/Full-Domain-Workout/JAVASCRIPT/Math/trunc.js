// trunc - Returns the integer part of x by removing any fractional digits.

let x=7.656587

console.log(Math.trunc(x));
