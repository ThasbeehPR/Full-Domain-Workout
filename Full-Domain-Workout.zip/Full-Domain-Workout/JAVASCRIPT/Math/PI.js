//PI    //constant value
console.log(Math.PI);