//create a new array that contain all 'keys' in an previous object

let obj ={a:1,b:2,c:3}

arr = Object.keys(obj)

console.log(arr);
