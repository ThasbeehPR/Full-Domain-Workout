// how to access c

let obj = {a:1,b:{c:2,d:3},e:4}


let result = obj.b.d

console.log(result);