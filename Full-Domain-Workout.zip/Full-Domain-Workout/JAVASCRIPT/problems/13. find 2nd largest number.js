// 13. find 2nd largest number

arr = [1,2,3,4,5,6,7]

const sort = arr.sort((a,b)=>(b-a))

console.log(sort[1]);