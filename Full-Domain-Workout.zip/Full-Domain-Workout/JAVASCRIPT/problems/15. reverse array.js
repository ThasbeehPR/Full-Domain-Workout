// 15. reverse array

arr = [1,2,3,4,5]

const rev = arr.reverse()

console.log(rev);