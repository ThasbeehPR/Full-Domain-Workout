//it give index number

arr=[5,4,3,2,1]
console.log(arr.indexOf(2));