//it merg
arr=[1,2,3]
arr = arr.concat(4,5,6)
console.log(arr);
