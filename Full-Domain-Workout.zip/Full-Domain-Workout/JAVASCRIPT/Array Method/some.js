//Higher order function
//it check some of value is true it show true

arr=[1,2,3,4,5]

arr1=arr.some((value)=>value%2==0)

console.log(arr1);