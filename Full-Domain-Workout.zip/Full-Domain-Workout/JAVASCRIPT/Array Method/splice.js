//to add, remove, or replace elements in an array. This method modifies the original array.
//array.splice(start, deleteCount, item1, item2, ...);

arr=[6, 7, 8, 5, 2]
arr.splice(0,1,44)
console.log(arr);
