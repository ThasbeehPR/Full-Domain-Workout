//Add last element
arr=[1,2,3]
arr.push(4)
console.log(arr);