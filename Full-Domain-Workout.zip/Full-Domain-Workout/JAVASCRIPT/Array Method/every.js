//it is a higher order function
//every is a condition to check every value is true/false
arr=[1,2,3,4,5]
arr1=arr.every((value)=>value%2==0)
console.log(arr1);