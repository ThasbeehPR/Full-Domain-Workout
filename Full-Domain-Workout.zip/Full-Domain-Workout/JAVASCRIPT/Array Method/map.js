//Higher order function
arr=[1,2,3,4,5]
arr1=arr.map((value)=>value*2)
console.log(arr1);