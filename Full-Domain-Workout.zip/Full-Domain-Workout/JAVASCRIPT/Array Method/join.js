//value come intermediate of each value
let arr = [1, 2, 3];
arr=arr.join(' @ ')
console.log(arr);
