//Examp 1

arr=[1,2,3,4,5]

arr1=arr.filter((value)=>value%2==0)

console.log(arr1);


//Examp 2

arr3=[1,2,3,4,5]

arr4=arr3.filter((value)=>value<4)

console.log(arr4);