//add extra element on first 
arr=[1,2,3]
arr.unshift(7)
console.log(arr);