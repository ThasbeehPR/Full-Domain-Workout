//remove first element from array
arr=[1,2,3]
arr.shift()
console.log(arr);