//it fill the value we give         //(value, start, end)   value-value     start-starting index    end-take one value before end
// const arr = Array(5).fill(10)
// console.log(arr);

arrr=[6,7,8,9,10]
const a4=arrr.fill(0,1,2)
console.log(a4);