//it give true/false when the element is present in it

arr=[5,4,3,2,1]
console.log(arr.includes(7));