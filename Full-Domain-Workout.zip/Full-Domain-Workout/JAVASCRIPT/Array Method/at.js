//ve pass index value it give its element
//+ve number check from starting / right side
//-ve number check from  ending / left  side


arr=[1,2,3,4,5]

arr1=arr.at(0)

console.log(arr1);