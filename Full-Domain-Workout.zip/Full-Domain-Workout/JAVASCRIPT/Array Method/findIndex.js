//get index value of what we find   //it only find the 1st element
arr=[5,4,3,2,1]
arr1=arr.findIndex((value)=>value%2==0)
console.log(arr1);