//delete last element
arr=[1,2,3]
arr.pop()
console.log(arr);