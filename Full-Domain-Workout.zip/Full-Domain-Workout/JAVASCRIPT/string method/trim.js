//remove start and end space
let word ="                  Hi  Bro   how are  you           "
let result = word.trim()

console.log(result)


//practise question  (check what datatype is output)
0
" " - 1 + 0
true + false
6 / "3"    //(for division also strings are converted to number)
"2" * "3"
4 + 5 + "px"
"$" + 4 + 5
"4" - 2
"4px" - 2
"  -9  " + 5
"  -9  " - 5
null + 1
undefined + 1
" \t \n" - 2