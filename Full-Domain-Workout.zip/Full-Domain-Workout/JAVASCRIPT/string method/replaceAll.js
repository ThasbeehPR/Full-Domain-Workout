let word = 'Thasbeeeee'
let change = word.replaceAll('e','i')
console.log(change);