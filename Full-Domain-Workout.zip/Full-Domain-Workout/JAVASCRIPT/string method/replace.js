//string replace
let word = 'Thasbee'
let change = word.replace('ee','i')
console.log(change);