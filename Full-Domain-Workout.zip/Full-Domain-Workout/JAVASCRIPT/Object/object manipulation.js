const me = {
    name:'Thasbii',
    age:22
}

//read
console.log(me.name);

//update
me.age=22
console.log(me);

//create
me.country='India'
console.log(me);

//delete
delete me.age
console.log(me);



