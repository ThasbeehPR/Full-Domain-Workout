//url pass
const url=require('url')

const result=url.parse('https://www.google.co.in/')

console.log(result);